HUNTA FREE DEMO KIT
===================
1. Open demo-card.html in any browser and TAP the buttons — that's the product.
2. Read the two PDFs: a real letter + CV rendered by the live engine
   (demo persona: Thabo Nkosi, the fictional example profile).
3. quickstart.md sets your own pipeline up in ~10 minutes (Discord webhook +
   Gmail app password; no card, no cloud console).
4. pricing.md: R0 demo forever / R299 Solo / R799 Studio / R2 499 Sovereign.

Questions? The landing page that sent you here pings a human — expect a reply
within a day. Free forever means free forever.

samples/: cv-classic/indigo/emerald/sunset.pdf are the SAME rendered files the hosted
gallery uses - open any to see the design applied; cover-letter-plain.pdf is what
always stays business-plain. demo-card.html rotates six jobs; the PDF buttons download
these samples. (demo-card links work offline too: it detects file:// and finds them here.)
