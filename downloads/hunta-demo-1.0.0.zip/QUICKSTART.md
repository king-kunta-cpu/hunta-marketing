# Quickstart (demo)

The five-command flow in README-FIRST.txt is the whole product. Extras:

- `hunta mailbox-test demo` — SMTP login check before anything goes out.
- `hunta llm-chain demo` — spreads load over free tiers (groq→cerebras→gemini→…) if you
  export the provider keys first. Studio plan feature, unlocked in demo.
- Demo state resets on demand: delete `data/.demo_usage.json` (one per install — this is
  goodwill, not DRM; the paid build has no leash because the paid build has your money).
- The purple one-liner at the bottom of generated PDFs disappears the moment HUNTA_FLAVOUR
  stops being `demo`.
- CV look is per candidate: `hunta designs` lists them (classic, indigo, emerald, sunset);
  `hunta design demo demo01 emerald` sets it. demo01 ships indigo, demo02 sunset — diff them
  side by side. Or edit `cv_design:` in the candidate YAML / the settings page dropdown.
