╔══════════════════════════════════════════════════════════════════╗
║  HUNTA 1.0.0 — FREE DEMO      Jobs found. Letters written. You tap ║
║  approve. It sends. (And yes — this banner is what the paid      ║
║  build does NOT have.)                                           ║
╚══════════════════════════════════════════════════════════════════╝

YOU HAVE: the actual product. Same code our paying agencies run,
on a demo leash: 25 drafted applications · 5 real email sends · 30 days.
Everything else — PDFs, Discord/Telegram approvals, dashboard — is uncut.

5 MINUTES TO FIRST SIGHT:
  python3.12 -m venv .venv && source .venv/bin/activate
  pip install hunta-1.0.0-py3-none-any.whl
  hunta keygen >> .env            # encrypts the keys you paste next (both free):
  #   groq.com -> free API key  ->  hunta encrypt gsk_...  -> paste into config/tenants/demo/tenant.yaml
  #   optional: a Gmail app password for the mailbox block (or leave blank and run --dry)
  hunta hunt --dry                # watch it find, score and draft REAL jobs — no email leaves the box
  hunta serve                     # dashboard http://localhost:8080 (demo strip included, by design)
  hunta doctor                    # what's set / what's missing

FEEDBACK LOOP: when a draft lands in your Discord card, tap ✅ and one of your
5 demo sends goes out — from the candidate's mailbox, to the real ad's address.
That moment is what $30/month buys.

  🔓 UPGRADE: https://whop.com/jacaranda-labs      (card, instant activation)
     ⚡ Lightning: SharkSkin@coinos.io
     🇿🇼🇿🇦 Mukuru / EFT: Mukuru / EFT: +263 78 460 0904 · ref = your tenant id
     or just reply to anything from bill@hunta.app — a human answers.

SHARING: the whole point. Re-send this ZIP to your other coaches, unmodified (see LICENSE
clause 2). Every one of them gets the same 30 days to feel the leash.

integrity: sha256 e6c313677c6518da6fc42f8aa956ab52a5261bd5c8213d9a9e6620d6d880ae24
