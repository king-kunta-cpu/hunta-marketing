╔══════════════════════════════════════════════════════════════════╗
║  HUNTA 1.0.0 — FREE DEMO      Jobs found. Letters written. You tap ║
║  approve. It sends. (And yes — this banner is what the paid      ║
║  build does NOT have.)                                           ║
╚══════════════════════════════════════════════════════════════════╝

⚠️ BUILD NOTE (seller): prices/rails still carry PLACEHOLDER values —
   fix hunta/demo.py BILLING and re-run the builder before publishing:
     · whop_url = https://shop.whop.com/hunta-PLACEHOLDER
     · lightning = hunta@coinos.io-PLACEHOLDER
     · mukuru = Mukuru / EFT: 077 XXX XXXX · ref = your tenant id

YOU HAVE: the actual product. Same code our paying agencies run,
on a demo leash: 25 drafted applications · 5 real email sends · 30 days.
Everything else — PDFs, Discord/Telegram approvals, dashboard — is uncut.

5 MINUTES TO FIRST SIGHT:
  python3.12 -m venv .venv && source .venv/bin/activate
  pip install hunta-1.0.0-py3-none-any.whl
  hunta keygen >> .env            # encrypts the keys you paste next (both free):
  #   groq.com -> free API key  ->  hunta encrypt gsk_...  -> paste into config/tenants/demo/tenant.yaml
  #   optional: a Gmail app password for the mailbox block (or leave blank and run --dry)
  hunta hunt --dry                # watch it find, score and draft REAL jobs — no email leaves the box
  hunta serve                     # dashboard http://localhost:8080 (demo strip included, by design)
  hunta doctor                    # what's set / what's missing

FEEDBACK LOOP: when a draft lands in your Discord card, tap ✅ and one of your
5 demo sends goes out — from the candidate's mailbox, to the real ad's address.
That moment is what R199/month buys.

  🔓 UPGRADE: https://shop.whop.com/hunta-PLACEHOLDER      (card, instant activation)
     ⚡ Lightning: hunta@coinos.io-PLACEHOLDER
     🇿🇼🇿🇦 Mukuru / EFT: Mukuru / EFT: 077 XXX XXXX · ref = your tenant id
     or just reply to anything from bill@hunta.app — a human answers.

SHARING: the whole point. Re-send this ZIP to your other coaches, unmodified (see LICENSE
clause 2). Every one of them gets the same 30 days to feel the leash.

integrity: sha256 71977ac083a02c392c5f608f29a62b4e1b028edbfe3cb3e966693c6c738d84e6
